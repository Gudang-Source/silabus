<?php
include "../config.php";
session_start();
$lab = $_POST['gedung'];
$tanggal = $_POST['tanggal'];
$idwaktu = $_POST['idwaktu'];
$idwaktu2 = $_POST['idwaktu2'];
$keterangan = $_POST['keterangan'];
$iduser = $_SESSION['iduser'];

$xtgl = date('Y-m-d', strtotime($tanggal));
$idhari = date('N', strtotime($xtgl));

$untukidlab=mysql_fetch_array(mysql_query("SELECT idlab from tblab where lab='$lab'"));
$idlab = $untukidlab['idlab'];
if(!empty($tanggal)){
		$z = $idwaktu2 - $idwaktu;
		for($x=0; $x<$z; $x++){
      $idwaktu=$idwaktu+$x;
			$query0 = mysql_query("SELECT j.* FROM tbjadwal j, tbhari h, tblab l, tbuser u, tbwaktu w WHERE (j.idlab=l.idlab AND j.idwaktu=w.idwaktu AND j.idhari=h.idhari AND j.iduser=u.iduser AND j.idhari='$idhari' AND w.idwaktu='$idwaktu' AND l.lab='$lab') OR j.tanggal='$xtgl'");
        
        if(mysql_num_rows($query0)==0){

          mysql_query("INSERT into silabus.tbjadwal (idlab,idwaktu,idhari,iduser,tanggal,keterangan,status) values ('$idlab','$idwaktu','$idhari','$iduser','$xtgl', '$keterangan','1')");
          echo "data sudah terupdate";
        }

        else{
         ?> <script type="text/javascript"> alert("Jadwal sudah terisi"); document.location.href='cari.php'; </script> <?php
        }
    }
}

else {
    ?> <script type="text/javascript"> alert("Masukkan parameter pencarian!"); document.location.href='cari.php'; </script> <?php
    }

?>